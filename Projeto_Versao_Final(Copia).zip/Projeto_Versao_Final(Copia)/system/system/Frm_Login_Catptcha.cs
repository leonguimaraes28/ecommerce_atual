﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace system
{
    public partial class Frm_Login_Catptcha : Form
    {
        public Frm_Login_Catptcha()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'ecommerceDataSet.tb_fornecedor' table. You can move, or remove it, as needed.
         //   this.tb_fornecedorTableAdapter.Fill(this.ecommerceDataSet.tb_fornecedor);

        }

        int number = 0;
        private void loadImage()
        {
            Random rdn = new Random();
            number = rdn.Next(100, 1000);
            var image = new Bitmap(this.pictureBox1.Width, this.pictureBox1.Height);
            var font = new Font("TimesNewRoman", 25, FontStyle.Bold, GraphicsUnit.Pixel);
            var graphics = Graphics.FromImage(image);
            graphics.DrawString(number.ToString(), font, Brushes.Green, new Point(0, 0));
            pictureBox1.Image = image;
        }

        private void btn_generate_Click(object sender, EventArgs e)
        {
            loadImage();
        }

        private void btn_verify_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == number.ToString())
                lbl_verify.Text = "Match text with Captcha";

            else
                lbl_verify.Text = "Does not Match Text with Captcha";

        }

        private void btn_generate_Click_1(object sender, EventArgs e)
        {
            loadImage();

        }
    }
}
