﻿using system.dal;//classe system.dal
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace system
{
    public partial class Frm_Product : Form
    {
        //SqlConnection myConn;
        public Frm_Product()
        {
            InitializeComponent();
        }

        private void Frm_Product_Load(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            //permite alimentar o gridview e o dropdown com os dados das tabelas produtos e categoria de produtos
            this.tbprodutoBindingSource.DataSource = dataContextFactory.DataContext.produtos;
            this.categoriaBindingSource.DataSource = dataContextFactory.DataContext.categorias;
               
        }


        private void btn_exit_Click(object sender, EventArgs e)
        {   //permite cancelar o registo de produtos no formulario
            this.tbprodutoBindingSource.CancelEdit();
        }

        private void btn_new_Click(object sender, EventArgs e)
        {
            //metodo que permite adicionar produto à base de dados
            this.tbprodutoBindingSource.AddNew();
            //this é o objeto, quando é criada a conexao é gerado o bindingsource, addnew é propriedade que permite adicionar

        }


        private bool checkData()//verifica se o textbox está vazio
        {
            if (string.IsNullOrEmpty(tb_name.Text) && string.IsNullOrEmpty(tb_description.Text) && string.IsNullOrEmpty(tb_ref.Text)
                && string.IsNullOrEmpty(tb_stock.Text) && string.IsNullOrEmpty(cb_category.Text))
            {
                MessageBox.Show("Para inserir produtos os campos não podem estar vazios!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else
                return true;
        }



        // private void btn_register_Click(object sender, EventArgs e)
        //{
        /*
                    if (checkData())//se nenhum dos campos estiverem vazios
                    {
                        tbprodutoBindingSource.EndEdit();
                        dataContextFactory.DataContext.SubmitChanges(); //faz as modificações na base de dados
                        dataGridView1.Refresh();//permite que o griedview atualize
                        MessageBox.Show("Produto inserido com sucesso");
                    }*/
        //}



        /* private void button1_Click(object sender, EventArgs e)
         {
             /* if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
              {
                  string selectedFile = openFileDialog1.FileName;
              }*

             OpenFileDialog open = new OpenFileDialog();
             open.Filter = "Image Files(*.jpeg;*.bmp;*.png;*.jpg)|*.jpeg;*.bmp;*.png;*.jpg";
             if (open.ShowDialog() == DialogResult.OK)
             {
                 tb_image.Text = open.FileName;
             }
             cn.Open();
             string image = tb_image.Text;
             Bitmap bmp = new Bitmap(image);
             FileStream fs = new FileStream(image, FileMode.Open, FileAccess.Read);
             byte[] bimage = new byte[fs.Length];
             fs.Read(bimage, 0, Convert.ToInt32(fs.Length));
             fs.Close();
             SqlCommand cmd = new SqlCommand("insert into tb_produto(imagem) values(@imgdata)", cn);
             cmd.Parameters.AddWithValue("@imgdata", SqlDbType.Image).Value = bimage;
             cmd.ExecuteNonQuery();
             cn.Close();

         }*/

        private void btn_delete_Click_1(object sender, EventArgs e)
        {

            if (DialogResult.Yes == MessageBox.Show("Delete the selected product?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
            {
                try
                {

                    this.tbprodutoBindingSource.RemoveCurrent();
                    dataContextFactory.DataContext.SubmitChanges();
                    MessageBox.Show("Product was removed from database", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btn_exit_Click_1(object sender, EventArgs e)
        {
            // this.tbprodutoBindingSource.CancelEdit();

        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            //  if (e.Value != null && e.ColumnIndex == 5)//coluna 5 contem a descrição do tipo de categoria do produto
            //    e.Value = Convert.ToInt32(((categoria)e.Value).tipo_categoria);



            if (e.Value != null && e.ColumnIndex == dataGridView1.Columns["id_categoria"].Index)
                e.Value = Convert.ToInt32(((categoria)e.Value).tipo_categoria);
        }

        private void btn_new_Click_2(object sender, EventArgs e)
        {
            

            groupBox1.Visible = true;
            this.tbprodutoBindingSource.AddNew();//adicionar registo ao gridview
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            OpenFileDialog opFile = new OpenFileDialog();
            opFile.Title = "Select image for this product";
            opFile.Filter = "jpg files (*.jpg)|*.jpg|All files (*.*)|*.*";
            if (opFile.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string iName = opFile.FileName;
                    var dir = @"images/" + GetCurrentId();
                    var path = Path.Combine(dir, Path.GetFileName(iName));
                    if (!Directory.Exists(dir))
                    {
                        Directory.CreateDirectory(dir);
                    }

                    File.Copy(iName, path);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Unable to open file " + ex.Message);
                }
            }
            else
            {
                opFile.Dispose();
            }
            if (openFileDialog1.FileName.ToString() != "")
            {
                string fileName = Path.GetFileName(opFile.FileName);
                tb_image.Text = fileName;
            }

           
           
        }

          private int GetCurrentId()
          {
            var result = dataContextFactory.DataContext.produtos.Max(x => x.id_produto);


            int maxId = Convert.ToInt32(result);
            if (maxId == 0) maxId = 1;
            else
                maxId++;

            return maxId;

        }


        /*  myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["ecommerceConnectionString"].ConnectionString);
          SqlCommand myCommand = new SqlCommand();




          myCommand.CommandType = CommandType.StoredProcedure;
          myCommand.CommandText = "max_id";

          SqlParameter valor = new SqlParameter();
          valor.ParameterName = "@retorno";
          valor.Direction = ParameterDirection.Output;
          valor.SqlDbType = SqlDbType.Int;

          myCommand.Parameters.Add(valor);

          myCommand.Connection = myConn;
          myConn.Open();
          myCommand.ExecuteNonQuery();

          int resposta = Convert.ToInt32(myCommand.Parameters["@retorno"].Value);


      return resposta + 1;






  }
*/

        private void btn_exit_Click_2(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (checkData())//se nenhum dos campos estiverem vazios
            {
                tbprodutoBindingSource.EndEdit();
                dataContextFactory.DataContext.SubmitChanges(); //faz as modificações na base de dados
                dataGridView1.Refresh();//permite que o griedview atualize
                MessageBox.Show("Produto inserido com sucesso");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.tbprodutoBindingSource.CancelEdit();

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            //check data aqui???
        }



    }
}
