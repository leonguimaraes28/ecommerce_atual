﻿namespace system
{
    partial class Frm_Login_Catptcha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gb_recaptcha = new System.Windows.Forms.GroupBox();
            this.lbl_verify = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btn_verify = new System.Windows.Forms.Button();
            this.btn_generate = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.gb_recaptcha.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // gb_recaptcha
            // 
            this.gb_recaptcha.Controls.Add(this.lbl_verify);
            this.gb_recaptcha.Controls.Add(this.textBox1);
            this.gb_recaptcha.Controls.Add(this.btn_verify);
            this.gb_recaptcha.Controls.Add(this.btn_generate);
            this.gb_recaptcha.Controls.Add(this.pictureBox1);
            this.gb_recaptcha.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_recaptcha.Location = new System.Drawing.Point(91, 96);
            this.gb_recaptcha.Name = "gb_recaptcha";
            this.gb_recaptcha.Size = new System.Drawing.Size(851, 331);
            this.gb_recaptcha.TabIndex = 10;
            this.gb_recaptcha.TabStop = false;
            this.gb_recaptcha.Text = "ReCaptcha";
            // 
            // lbl_verify
            // 
            this.lbl_verify.AutoSize = true;
            this.lbl_verify.Location = new System.Drawing.Point(132, 303);
            this.lbl_verify.Name = "lbl_verify";
            this.lbl_verify.Size = new System.Drawing.Size(0, 25);
            this.lbl_verify.TabIndex = 5;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(128, 261);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(333, 30);
            this.textBox1.TabIndex = 4;
            // 
            // btn_verify
            // 
            this.btn_verify.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_verify.Location = new System.Drawing.Point(487, 261);
            this.btn_verify.Name = "btn_verify";
            this.btn_verify.Size = new System.Drawing.Size(97, 30);
            this.btn_verify.TabIndex = 3;
            this.btn_verify.Text = "Verifiy";
            this.btn_verify.UseVisualStyleBackColor = true;
            // 
            // btn_generate
            // 
            this.btn_generate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_generate.Location = new System.Drawing.Point(545, 103);
            this.btn_generate.Name = "btn_generate";
            this.btn_generate.Size = new System.Drawing.Size(126, 42);
            this.btn_generate.TabIndex = 2;
            this.btn_generate.Text = "Generate";
            this.btn_generate.UseVisualStyleBackColor = true;
            this.btn_generate.Click += new System.EventHandler(this.btn_generate_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(76, 29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(429, 205);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Frm_Login_Catptcha
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(1032, 590);
            this.Controls.Add(this.gb_recaptcha);
            this.Name = "Frm_Login_Catptcha";
            this.Text = "ReCatpcha";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gb_recaptcha.ResumeLayout(false);
            this.gb_recaptcha.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gb_recaptcha;
        private System.Windows.Forms.Label lbl_verify;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btn_verify;
        private System.Windows.Forms.Button btn_generate;
        private System.Windows.Forms.PictureBox pictureBox1;
       // private ecommerceDataSet ecommerceDataSet;
    }
}